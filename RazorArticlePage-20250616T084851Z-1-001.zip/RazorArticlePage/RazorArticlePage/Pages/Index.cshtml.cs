using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RazorArticlePage.Models;

namespace RazorArticlePage.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly RazorArticlePage.Data.ApplicationDbContext _context;

        public IndexModel(ILogger<IndexModel> logger, RazorArticlePage.Data.ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IList<Article> Article { get; set; } = default!;
        [BindProperty(SupportsGet = true)]
        public string? SearchTerm { get; set; }
        public async Task OnGetAsync()
        {
            var query = _context.Articles.AsQueryable();

            if (!string.IsNullOrEmpty(SearchTerm))
            {
                query = query.Where(a =>
                    a.Title.Contains(SearchTerm) || a.Content.Contains(SearchTerm));
            }

            Article = await query.ToListAsync();
        }

        public async Task<IActionResult> OnPostApplyAsync(int articleId)
        {
            var article = await _context.Articles.FindAsync(articleId);

            if (article == null)
            {
                return NotFound();
            }

            return RedirectToPage("/JobApplication", new { articleId = article.Id });
        }
    }
}
