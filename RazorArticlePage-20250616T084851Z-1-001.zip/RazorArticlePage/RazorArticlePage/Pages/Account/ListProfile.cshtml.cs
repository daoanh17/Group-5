using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorArticlePage.Models;
using RazorArticlePage.ViewModels;

namespace RazorArticlePage.Pages.Account
{
    public class ListProfileModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public ListProfileModel(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        public IList<UserWithRoleViewModel> ListUser { get; set; } = new List<UserWithRoleViewModel>();

        public bool IsAdmin { get; set; }

        public async Task OnGetAsync()
        {
            var allUsers = _userManager.Users.ToList();
            var currentUser = await _userManager.GetUserAsync(User);
            var currentRoles = await _userManager.GetRolesAsync(currentUser);
            IsAdmin = currentRoles.Contains("Admin");
            foreach (var user in allUsers)
            {
                var roles = await _userManager.GetRolesAsync(user);
                if (roles.Contains("User"))
                {
                    ListUser.Add(new UserWithRoleViewModel
                    {
                        Id = user.Id,
                        UserName = user.UserName,
                        Email = user.Email,
                        FullName = user.FullName,
                        Role = string.Join(", ", roles)
                    });
                }
            }
        }

    }
}
