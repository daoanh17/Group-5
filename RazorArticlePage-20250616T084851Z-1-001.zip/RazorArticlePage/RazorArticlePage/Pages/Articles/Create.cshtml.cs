﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using RazorArticlePage.Data;
using RazorArticlePage.Models;

namespace RazorArticlePage.Pages.Articles
{
    [Authorize(Roles = "Admin, User")]
    public class CreateModel : PageModel
    {
        private readonly RazorArticlePage.Data.ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public CreateModel(RazorArticlePage.Data.ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public CreateArticlesInputModel Input { get; set; }

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            Article dto = new Article
            {
                Content = Input.Content,
                AuthorId = _userManager.GetUserId(User),
                Title = Input.Title
            };


            _context.Articles.Add(dto);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
        public class CreateArticlesInputModel
        {
            [Required]
            public string Title { get; set; }
            [Required]
            public string Content { get; set; }
        }
    }
}
