﻿namespace RazorArticlePage.Models
{
    // JobPosting 
    public class Article
    {
        public int Id { get; set; }
        public string Title { get; set; } // Tên vị trí tuyển
        public string Content { get; set; } // Mô tả công việc
        public string AuthorId { get; set; } // Id người đăng (nhà tuyển dụng)
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public ICollection<JobApplication> JobApplications { get; set; }

    }

}