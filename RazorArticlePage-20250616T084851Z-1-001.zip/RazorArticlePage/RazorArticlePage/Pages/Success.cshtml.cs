using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RazorArticlePage.Data;
using RazorArticlePage.Models;
using System.Security.Claims;

namespace RazorArticlePage.Pages
{
    public class SuccessModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public SuccessModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<JobApplication> Applications { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            if (User.IsInRole("Admin"))
            {
                Applications = await _context.JobApplications
                    .Include(j => j.Article)
                    .Include(j => j.User) 
                    .OrderByDescending(j => j.AppliedAt)
                    .ToListAsync();
            }
            else
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (userId == null)
                {
                    return RedirectToPage("/Account/Login");
                }

                Applications = await _context.JobApplications
                    .Include(j => j.Article)
                    .Where(j => j.UserId == userId)
                    .OrderByDescending(j => j.AppliedAt)
                    .ToListAsync();
            }

            return Page();
        }

    }
}
