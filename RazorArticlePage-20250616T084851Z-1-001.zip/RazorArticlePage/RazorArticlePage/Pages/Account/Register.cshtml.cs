using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Rewrite;
using RazorArticlePage.Models;
using RazorArticlePage.Utils;
using System.ComponentModel.DataAnnotations;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace RazorArticlePage.Pages.Accounts
{
    public class RegisterModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ILogger<RegisterModel> _logger;
        [BindProperty] public RegisterInputModel Input { get; set; }
        public RegisterModel(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, ILogger<RegisterModel> logger)
        {
            (_userManager, _signInManager) = (userManager, signInManager);
            _logger = logger;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!Helper.ComparePasswords(Input.Password, Input.ConfirmPassword))
            {
                ModelState.AddModelError(string.Empty, "Passwords do not match.");
                return Page();
            }

            var user = new ApplicationUser
            {
                UserName = Input.Email,
                Email = Input.Email,
                FullName = Input.FullName
            };

    
            var result = await _userManager.CreateAsync(user, Input.Password);
            if (!result.Succeeded)
            {
                ModelState.AddModelError(string.Empty, "Passwords do not match.");
                return Page();
            }
            if (result.Succeeded)
            {
                _logger.LogInformation($"Successfully registered user: {Input.Email}");

                var roleResult = await _userManager.AddToRoleAsync(user, "User");
                if (!roleResult.Succeeded)
                {
                    foreach (var error in roleResult.Errors)
                        ModelState.AddModelError(string.Empty, $"Role error: {error.Description}");
                    return Page();
                }

                await _signInManager.SignInAsync(user, false);
                return RedirectToPage("/Index");
            }

            foreach (var error in result.Errors)
                ModelState.AddModelError(string.Empty, error.Description);

            return Page();
        }

        public class RegisterInputModel
        {
            [Required] public string Email { get; set; }
            [Required][DataType(DataType.Password)] public string Password { get; set; }
            [Required]
            [Display(Name = "Full Name")]
            public string FullName { get; set; }
            [Required]
            [DataType(DataType.Password)]
            [Compare("Password", ErrorMessage = "Passwords do not match.")]
            public string ConfirmPassword { get; set; }
        }
    }

}
