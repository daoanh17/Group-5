using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorArticlePage.Models;

namespace RazorArticlePage.Pages.Account
{
    public class EditUserModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public EditUserModel(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        [BindProperty]
        public string Id { get; set; }
        [BindProperty]
        public string Email { get; set; }
        [BindProperty]
        public string FullName { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await _userManager.FindByIdAsync(Id);
            if (user == null)
            {
                return NotFound();
            }

            user.Email = Email;
            user.FullName = FullName;

            await _userManager.UpdateAsync(user);
            return RedirectToPage("/Account/ListProfile");
        }
    }

}
