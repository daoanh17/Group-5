﻿namespace RazorArticlePage.Utils
{
    public static class Helper
    {
        public static bool ComparePasswords(string password1, string password2)
        {
            if (string.IsNullOrWhiteSpace(password1) || string.IsNullOrWhiteSpace(password2))
                return false;

            return password1.Trim() == password2.Trim();
        }
    }
}
