﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RazorArticlePage.Models;

namespace RazorArticlePage.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
        }
       
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<JobApplication>()
                .HasOne(j => j.User) // Mỗi JobApplication sẽ có một ApplicationUser
                .WithMany(u => u.JobApplications) // ApplicationUser sẽ có nhiều JobApplications
                .HasForeignKey(j => j.UserId) // Chỉ định khóa ngoại
                .OnDelete(DeleteBehavior.Cascade); // Xóa JobApplication khi xóa ApplicationUser

            builder.Entity<JobApplication>()
                .HasOne(j => j.Article) // Mỗi JobApplication sẽ có một Article
                .WithMany(a => a.JobApplications) // Article sẽ có nhiều JobApplications
                .HasForeignKey(j => j.ArticleId) // Chỉ định khóa ngoại
                .OnDelete(DeleteBehavior.Cascade); // Xóa JobApplication khi xóa Article
        }

        public DbSet<Article> Articles { get; set; }
        public DbSet<JobApplication> JobApplications { get; set; }
    }
}
