﻿namespace RazorArticlePage.Models
{
    // Đơn ứng tuyển
    public class JobApplication
    {
        public int Id { get; set; }

        public string? ResumeUrl { get; set; }
        public DateTime AppliedAt { get; set; }

        // FK đến ApplicationUser
        public string UserId { get; set; }
        public ApplicationUser User { get; set; }

        // FK đến Article
        public int ArticleId { get; set; }
        public Article Article { get; set; }
    }
}
