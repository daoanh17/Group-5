﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using RazorArticlePage.Models;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace RazorArticlePage.Pages
{
    public class JobApplicationModel : PageModel
    {
        private readonly RazorArticlePage.Data.ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        public JobApplicationModel(RazorArticlePage.Data.ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [BindProperty]
        public JobApplicationForm ApplicationForm { get; set; }

        public Article Article { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(int articleId)
        {
            // Lấy thông tin Article từ database
            Article = await _context.Articles.FirstOrDefaultAsync(a => a.Id == articleId);

            if (Article == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int articleId)
        {
            if (!ModelState.IsValid)
            {
                return Page(); 
            }

            var file = Request.Form.Files["CVFile"];
            if (file == null)
            {
                ModelState.AddModelError("CVFile", "Please upload your CV.");
                return Page();  
            }

            var extension = Path.GetExtension(file.FileName).ToLower();
            if (extension != ".pdf" && extension != ".docx" && extension != ".doc")
            {
                ModelState.AddModelError("CVFile", "Only PDF and Word files are allowed.");
                return Page();  
            }


            var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
            if (!Directory.Exists(uploadPath))
            {
                Directory.CreateDirectory(uploadPath);  
            }
            var filePath = Path.Combine(uploadPath, file.FileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);  
            }

            var jobApplication = new JobApplication
            {
                UserId = _userManager.GetUserId(User),
                ArticleId = articleId,
                ResumeUrl = $"/uploads/{file.FileName}", 
                AppliedAt = DateTime.Now
            };

            _context.JobApplications.Add(jobApplication);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Success");
        }

    }
    public class JobApplicationForm
    {
        public IFormFile CVFile { get; set; }
    }
}
